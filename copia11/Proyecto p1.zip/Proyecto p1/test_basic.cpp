#include <iostream>

int main() {
    std::cout << "Programa iniciado" << std::endl;
    std::cout.flush();
    return 0;
}
